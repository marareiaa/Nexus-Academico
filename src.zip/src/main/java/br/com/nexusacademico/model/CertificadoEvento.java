
package br.com.nexusacademico.model;

import java.time.LocalDateTime;
import java.util.UUID;

public class CertificadoEvento {

    private String codigoVerificacao;
    private LocalDateTime dataEmissao;
    private int cargaHoraria;
    private String url;

    public CertificadoEvento(int cargaHoraria, String url) {

        if (cargaHoraria <= 0) {
            throw new IllegalArgumentException(
                    "A carga horária deve ser maior que zero."
            );
        }

        this.cargaHoraria = cargaHoraria;
        this.url = url;
    }

    public String getCodigoVerificacao() {
        return codigoVerificacao;
    }

    public LocalDateTime getDataEmissao() {
        return dataEmissao;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public String getUrl() {
        return url;
    }

    public void gerar() {

        if (codigoVerificacao != null) {
            throw new IllegalStateException(
                    "Este certificado já foi gerado."
            );
        }

        this.codigoVerificacao = UUID.randomUUID()
                .toString()
                .replace("-", "")
                .toUpperCase();

        this.dataEmissao = LocalDateTime.now();
    }

    public boolean validar(String codigo) {

        return codigoVerificacao != null
                && codigo != null
                && codigoVerificacao.equalsIgnoreCase(codigo.trim());
    }
}
