
package br.com.nexusacademico.model;

import java.time.LocalDateTime;

public class InscricaoEvento {

    private int idInscricao;
    private int idAluno;
    private int idEvento;

    private LocalDateTime dataInscricao;
    private String status;
    private boolean presente;

    public InscricaoEvento(int idAluno, int idEvento) {

        this.idAluno = idAluno;
        this.idEvento = idEvento;
        this.dataInscricao = LocalDateTime.now();
        this.status = "confirmada";
        this.presente = false;
    }

    public int getIdInscricao() {
        return idInscricao;
    }

    public int getIdAluno() {
        return idAluno;
    }

    public int getIdEvento() {
        return idEvento;
    }

    public LocalDateTime getDataInscricao() {
        return dataInscricao;
    }

    public String getStatus() {
        return status;
    }

    public boolean isPresente() {
        return presente;
    }

    public void setIdInscricao(int idInscricao) {
        this.idInscricao = idInscricao;
    }

    public void confirmar() {
        this.status = "confirmada";
    }

    public void cancelar() {
        this.status = "cancelada";
    }

    public void registrarPresenca() {

        if (!"confirmada".equals(this.status)) {
            throw new IllegalStateException(
                    "Não é possível registrar presença em uma inscrição não confirmada."
            );
        }

        this.presente = true;
    }
}
