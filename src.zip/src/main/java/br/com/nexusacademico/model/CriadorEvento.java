
package br.com.nexusacademico.model;

import java.time.LocalDateTime;

public class CriadorEvento extends Usuario {

    // Identifica a categoria do criador do evento.
    private String tipoCriador;

    // Instituição à qual o criador está vinculado.
    private String instituicao;

    // Construtor para cadastrar um novo criador de eventos.
    public CriadorEvento(
            String nome,
            String email,
            String senhaHash,
            String tipoCriador,
            String instituicao
    ) {
        super(nome, email, senhaHash);

        this.tipoCriador = tipoCriador;
        this.instituicao = instituicao;
    }

    // Construtor para recuperar um criador do banco de dados.
    public CriadorEvento(
            int idUsuario,
            String nome,
            String email,
            String senhaHash,
            LocalDateTime dataCadastro,
            String tipoCriador,
            String instituicao
    ) {
        super(idUsuario, nome, email, senhaHash, dataCadastro);

        this.tipoCriador = tipoCriador;
        this.instituicao = instituicao;
    }

    // Retorna o tipo de criador.
    public String getTipoCriador() {
        return tipoCriador;
    }

    // Retorna a instituição do criador.
    public String getInstituicao() {
        return instituicao;
    }

    // Atualiza o tipo de criador.
    public void setTipoCriador(String tipoCriador) {
        this.tipoCriador = tipoCriador;
    }

    // Atualiza a instituição do criador.
    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }

    // Implementa a autenticação herdada de Usuario.
    @Override
    public boolean autenticar(String senhaInformada) {
        return super.autenticar(senhaInformada);
    }
}
